#
# The Mule Secure Data Gateway Client provides a secure data link between your CloudHub application
# and private network. Below are a few simple steps to configure the connector.
#


* Customize the /conf/config.xml file.

    Basic authentication over HTTPS is currently required for integration with the CloudHub platform server.
    Your credentials are encrypted before being sent to the server.

    <username>myusername</username>
    <password>mypassword</password>

* Add port mappings to the /conf/mappings.xml file.

    Local services on your private network are made available to your CloudHub apps via http/ssh secure port forwarding.
    Add port mapping configurations to this file for each private data source you wish to access.

    For example:

    <mappings>
        <mapping>
            <remotePort>10000</remotePort>
            <privateHost>my.private.database</privateHost>
            <privatePort>3306</privatePort>
        </mapping>
    </mappings>

    This config snippet instructs the SDG Client to forward your CloudHub worker local port 10000 to
    port 3306 on my.private.database.

    Any transports in your Mule config can be connected to private data sources via this mechanism.

* Refer to port mappings in your CloudHub mule config.
    
    With the above mapping, a jdbc endpoint can easily be configured to write data to the private database.
    The example mule config below writes incoming http parameters to an cloudhub_db_table on the private mysql database.

    <?xml version="1.0" encoding="UTF-8"?>
    <mule xmlns="http://www.mulesoft.org/schema/mule/core"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:spring="http://www.springframework.org/schema/beans"
        xmlns:jdbc="http://www.mulesoft.org/schema/mule/ee/jdbc"
        xmlns:context="http://www.springframework.org/schema/context"

        xsi:schemaLocation="
           http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd
           http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/3.1/mule.xsd
           http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.0.xsd
           http://www.mulesoft.org/schema/mule/ee/jdbc http://www.mulesoft.org/schema/mule/ee/jdbc/3.1/mule-jdbc-ee.xsd">

        <spring:bean id="dataSource"
            class="org.springframework.jdbc.datasource.SimpleDriverDataSource">
            <spring:property name="driverClass" value="com.mysql.jdbc.Driver"/>
            <spring:property name="url" value="jdbc:mysql://localhost:10000/cloudhub_test"/>
            <spring:property name="username" value="mysqluser"/>
            <spring:property name="password" value="password"/>
        </spring:bean>

        <jdbc:connector name="jdbcConnector" dataSource-ref="dataSource">
            <jdbc:query key="cloudhubTestInsert"
                value="insert into cloudhub_test_table values
                (#[header:inbound:text])"/>
        </jdbc:connector>

        <flow name="jdbctest">
           <inbound-endpoint address="http://localhost:${http.port}/jdbctest"/>
           <jdbc:outbound-endpoint queryKey="cloudhubTestInsert"/>
       </flow>
    </mule>

    update the username and password to match those in use on the private database server.

* To test the above CloudHub application

    - create a test mysql database table on my.private.database port 3306

      CREATE DATABASE `cloudhub_test` /*!40100 DEFAULT CHARACTER SET utf8 */;
      USE cloudhub_test;
      CREATE TABLE `cloudhub_test_table` (`message` varchar(30) DEFAULT NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8;

    - ensure correct user privileges for the user on the agent machine
      e.g  GRANT ALL PRIVILEGES ON cloudhub_test.* TO 'mysqluser'@'sdghost'
           FLUSH PRIVILEGES

    - deploy the test Mule application on CloudHub

    - point your web browser to http://yourdomain.cloudhub.io/jdbctest?text=TEST 

    - verify that the above value parameter has been written to the cloudhub_test_table table

    
